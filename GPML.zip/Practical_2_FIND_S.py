# PRACTICAL 2: FIND-S ALGORITHM
import csv

# Create a small EnjoySport training dataset (last column is target)
rows = [
    ["Sky", "AirTemp", "Humidity", "Wind", "Water", "Forecast", "EnjoySport"],
    ["Sunny", "Warm", "Normal", "Strong", "Warm", "Same", "Yes"],
    ["Sunny", "Warm", "High", "Strong", "Warm", "Same", "Yes"],
    ["Rainy", "Cold", "High", "Strong", "Warm", "Change", "No"],
    ["Sunny", "Warm", "High", "Strong", "Cool", "Change", "Yes"]
]
with open("enjoysport.csv", "w", newline="") as f:
    csv.writer(f).writerows(rows)

with open("enjoysport.csv", "r", newline="") as f:
    reader = list(csv.reader(f))

attributes = reader[0][:-1]
training_data = reader[1:]
hypothesis = None

print("Training data:")
for row in training_data:
    print(row)

for example in training_data:
    if example[-1].strip().lower() == "yes":
        values = example[:-1]
        if hypothesis is None:
            hypothesis = values.copy()
        else:
            for i in range(len(hypothesis)):
                if hypothesis[i] != values[i]:
                    hypothesis[i] = "?"
        print("Hypothesis after positive example:", hypothesis)

print("\nMost specific hypothesis:", hypothesis)
print("Practical 2 completed.")
