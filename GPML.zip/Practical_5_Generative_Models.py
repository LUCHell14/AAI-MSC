# PRACTICAL 5: GENERATIVE MODELS
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from hmmlearn import hmm

# 1. Naive Bayes classifier
iris = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    iris.data, iris.target, test_size=0.4, random_state=1)
model = GaussianNB()
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("NAIVE BAYES ACCURACY:", accuracy_score(y_test, pred) * 100, "%")
print("Predicted classes:", pred[:10])

# 2. Hidden Markov Model
states = ["Sunny", "Rainy"]
start_probability = np.array([0.6, 0.4])
transition_probability = np.array([[0.7, 0.3],
                                  [0.3, 0.7]])
emission_probability = np.array([[0.9, 0.1],
                                 [0.2, 0.8]])
model = hmm.CategoricalHMM(n_components=2, n_iter=100)
model.startprob_ = start_probability
model.transmat_ = transition_probability
model.emissionprob_ = emission_probability

# 0 = Dry, 1 = Wet
observations = np.array([0, 1, 0, 1, 0, 0]).reshape(-1, 1)
hidden_states = model.predict(observations)
print("\nHIDDEN MARKOV MODEL")
print("Observation sequence (0=Dry, 1=Wet):", observations.ravel())
print("Most likely hidden states:", hidden_states)
print("State names:", [states[i] for i in hidden_states])
plt.plot(hidden_states, marker="o")
plt.yticks([0, 1], states)
plt.xlabel("Time step")
plt.ylabel("Hidden state")
plt.title("HMM: Sunny or Rainy")
plt.show()
print("\nPractical 5 completed.")
