# PRACTICAL 6: PROBABILISTIC MODELS
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.mixture import GaussianMixture

# 1. Bayesian Linear Regression using Pyro
import torch
import pyro
import pyro.distributions as dist
from pyro.infer import SVI, Trace_ELBO, Predictive
from pyro.optim import Adam

pyro.clear_param_store()
torch.manual_seed(0)
X = torch.linspace(0, 10, 100)
Y = 1 + 2 * X + torch.randn(100)

def model(x, y=None):
    slope = pyro.sample("slope", dist.Normal(0., 10.))
    intercept = pyro.sample("intercept", dist.Normal(0., 10.))
    sigma = pyro.sample("sigma", dist.HalfNormal(1.))
    mu = intercept + slope * x
    with pyro.plate("data", len(x)):
        pyro.sample("obs", dist.Normal(mu, sigma), obs=y)

def guide(x, y=None):
    slope_loc = pyro.param("slope_loc", torch.tensor(0.))
    slope_scale = pyro.param("slope_scale", torch.tensor(1.),
                             constraint=dist.constraints.positive)
    int_loc = pyro.param("int_loc", torch.tensor(0.))
    int_scale = pyro.param("int_scale", torch.tensor(1.),
                           constraint=dist.constraints.positive)
    sigma_scale = pyro.param("sigma_scale", torch.tensor(1.),
                             constraint=dist.constraints.positive)
    pyro.sample("slope", dist.Normal(slope_loc, slope_scale))
    pyro.sample("intercept", dist.Normal(int_loc, int_scale))
    pyro.sample("sigma", dist.HalfNormal(sigma_scale))

svi = SVI(model, guide, Adam({"lr": 0.01}), loss=Trace_ELBO())
for step in range(1000):
    loss = svi.step(X, Y)
    if (step + 1) % 200 == 0:
        print("Iteration", step + 1, "Loss:", round(loss, 2))

posterior = Predictive(model, guide=guide, num_samples=500)(X)
print("Estimated slope:", posterior["slope"].mean().item())
print("Estimated intercept:", posterior["intercept"].mean().item())
print("Estimated sigma:", posterior["sigma"].mean().item())

# 2. Gaussian Mixture Model for clustering
iris = load_iris()
features = iris.data[:, :2]
gmm = GaussianMixture(n_components=3, random_state=42)
gmm.fit(features)
labels = gmm.predict(features)
print("\nGAUSSIAN MIXTURE MODEL")
print("Cluster labels:", labels)
print("Log likelihood:", gmm.lower_bound_)
print("Iterations:", gmm.n_iter_)
plt.scatter(features[:, 0], features[:, 1], c=labels)
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])
plt.title("Gaussian Mixture Model Clusters")
plt.show()
print("\nPractical 6 completed.")
