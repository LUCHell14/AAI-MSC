M.Sc. IT - Machine Learning Practicals 1 to 9
For Windows + Python IDLE

SETUP
1. Install Python 3.11 (64-bit) from https://www.python.org/downloads/
2. During installation, tick "Add Python to PATH".
3. Open Command Prompt (CMD), not the IDLE Shell.
4. Run:
   py -m pip install --upgrade pip
   py -m pip install numpy==1.26.4 pandas matplotlib seaborn scikit-learn openpyxl statsmodels hmmlearn pyro-ppl xgboost bayesian-optimization torch torchvision
5. Open IDLE. Choose File > Open and open one practical .py file.
6. Press F5 to run. Save files before running.

IMPORTANT
- These programs are corrected, simplified, exam-practice versions based on the topics in your uploaded journal.
- Practical 1 and Practical 2 create small sample CSV files automatically, so you can run them without finding the journal's original files.
- Practical 9 downloads CIFAR-10 the first time. It needs internet and can take several minutes. CPU training can be slow.
- Graphs appear in separate windows. Close a graph window to allow the program to continue.
- Do not type pip install commands into the IDLE >>> prompt. Use CMD.
- If `py` is not recognized, use `python -m pip ...` instead.
