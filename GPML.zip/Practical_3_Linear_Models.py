# PRACTICAL 3: LINEAR MODELS
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.metrics import mean_squared_error, r2_score

# 1. Simple Linear Regression
np.random.seed(42)
x = np.arange(1, 51).reshape(-1, 1)
y = 5 + 3 * x.ravel() + np.random.normal(0, 8, 50)
X_train, X_test, y_train, y_test = train_test_split(
    x, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("SIMPLE LINEAR REGRESSION")
print("Coefficient:", model.coef_[0])
print("Intercept:", model.intercept_)
print("MSE:", mean_squared_error(y_test, pred))
print("R-squared:", r2_score(y_test, pred))
plt.scatter(x, y, label="Data")
plt.plot(x, model.predict(x), color="red", label="Regression line")
plt.xlabel("X")
plt.ylabel("Y")
plt.legend()
plt.title("Simple Linear Regression")
plt.show()

# 2. Multiple Linear Regression and multicollinearity example
X, y_multi = make_regression(n_samples=250, n_features=4, noise=15, random_state=1)
X_train, X_test, y_train, y_test = train_test_split(
    X, y_multi, test_size=0.2, random_state=42)
multi = LinearRegression()
multi.fit(X_train, y_train)
pred = multi.predict(X_test)
print("\nMULTIPLE LINEAR REGRESSION")
print("Coefficients:", multi.coef_)
print("MSE:", mean_squared_error(y_test, pred))
print("R-squared:", r2_score(y_test, pred))

# 3. Ridge, Lasso and ElasticNet
print("\nREGULARIZED LINEAR MODELS")
for name, reg in [
    ("Ridge", Ridge(alpha=1.0)),
    ("Lasso", Lasso(alpha=0.1)),
    ("ElasticNet", ElasticNet(alpha=0.1, l1_ratio=0.5))
]:
    reg.fit(X_train, y_train)
    p = reg.predict(X_test)
    print(name, "MSE:", round(mean_squared_error(y_test, p), 3),
          "R2:", round(r2_score(y_test, p), 3))
print("\nPractical 3 completed.")
