# PRACTICAL 7: MODEL EVALUATION AND HYPERPARAMETER TUNING
from sklearn.datasets import load_breast_cancer, load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import (StratifiedKFold, cross_val_score,
                                     train_test_split, GridSearchCV,
                                     RandomizedSearchCV)
from sklearn.tree import DecisionTreeClassifier
from scipy.stats import randint
import numpy as np

# 1. Stratified K-Fold Cross Validation
data = load_breast_cancer()
X, y = data.data, data.target
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000))
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=1)
scores = cross_val_score(model, X, y, cv=skf, scoring="accuracy")
print("STRATIFIED 10-FOLD CROSS VALIDATION")
print("Fold accuracies:", scores)
print("Maximum accuracy:", scores.max() * 100, "%")
print("Minimum accuracy:", scores.min() * 100, "%")
print("Mean accuracy:", scores.mean() * 100, "%")
print("Standard deviation:", scores.std())

# 2. Grid Search and Randomized Search
iris = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    iris.data, iris.target, test_size=0.2, random_state=42)
tree = DecisionTreeClassifier(random_state=42)
param_grid = {
    "max_depth": [2, 3, 5, 7, None],
    "min_samples_split": [2, 5, 10]
}
grid = GridSearchCV(tree, param_grid, cv=5, scoring="accuracy")
grid.fit(X_train, y_train)
print("\nGRID SEARCH")
print("Best parameters:", grid.best_params_)
print("Best CV score:", grid.best_score_)
print("Test accuracy:", grid.score(X_test, y_test))

param_dist = {
    "max_depth": randint(2, 15),
    "min_samples_split": randint(2, 15)
}
random_search = RandomizedSearchCV(
    DecisionTreeClassifier(random_state=42),
    param_distributions=param_dist, n_iter=15, cv=5,
    random_state=42, scoring="accuracy")
random_search.fit(X_train, y_train)
print("\nRANDOMIZED SEARCH")
print("Best parameters:", random_search.best_params_)
print("Best CV score:", random_search.best_score_)
print("Test accuracy:", random_search.score(X_test, y_test))
print("\nPractical 7 completed.")
