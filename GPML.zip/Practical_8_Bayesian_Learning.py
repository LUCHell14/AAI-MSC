# PRACTICAL 8: BAYESIAN LEARNING USING INFERENCE
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

# Generate sample observations
true_mu = 5
true_sigma = 2
data = np.random.normal(true_mu, true_sigma, size=100)

# Prior parameters
prior_mu_mean = 0
prior_mu_precision = 1
prior_sigma_alpha = 2
prior_sigma_beta = 2

# Posterior parameters (normal mean with known observation variance)
n = len(data)
posterior_mu_precision = prior_mu_precision + n / (true_sigma ** 2)
posterior_mu_mean = (
    prior_mu_precision * prior_mu_mean + np.sum(data) / (true_sigma ** 2)
) / posterior_mu_precision

posterior_sigma_alpha = prior_sigma_alpha + n / 2
posterior_sigma_beta = prior_sigma_beta + np.sum(
    (data - np.mean(data)) ** 2
) / 2

# Draw samples from posterior distributions
posterior_mu = np.random.normal(
    posterior_mu_mean, 1 / np.sqrt(posterior_mu_precision), 10000)
posterior_variance = 1 / np.random.gamma(
    posterior_sigma_alpha, 1 / posterior_sigma_beta, 10000)
posterior_sigma = np.sqrt(posterior_variance)

print("BAYESIAN LEARNING")
print("Mean of posterior mu:", np.mean(posterior_mu))
print("Standard deviation of mu:", np.std(posterior_mu))
print("Mean of posterior sigma:", np.mean(posterior_sigma))
print("Standard deviation of sigma:", np.std(posterior_sigma))

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1)
plt.hist(posterior_mu, bins=30, density=True)
plt.title("Posterior distribution of mu")
plt.xlabel("mu")
plt.ylabel("Density")

plt.subplot(1, 2, 2)
plt.hist(posterior_sigma, bins=30, density=True)
plt.title("Posterior distribution of sigma")
plt.xlabel("sigma")
plt.ylabel("Density")
plt.tight_layout()
plt.show()
print("\nPractical 8 completed.")
