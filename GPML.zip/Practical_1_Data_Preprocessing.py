# PRACTICAL 1: DATA PRE-PROCESSING AND EXPLORATION
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder, StandardScaler, Binarizer

print("\nPART A: Missing values, formatting and outliers")
df = pd.DataFrame({
    "Name": ["Asha", " Ravi ", "Meena", "John", "Sara", "Ali"],
    "Country": ["India ", " India", "USA", "UK ", None, "India"],
    "Age": [22, 25, np.nan, 31, 29, 150],
    "Salary": [25000, 30000, 28000, np.nan, 35000, 900000]
})
df.to_csv("customers_sample.csv", index=False)
df = pd.read_csv("customers_sample.csv")
print("Original data:\n", df)
df["Name"] = df["Name"].str.strip()
df["Country"] = df["Country"].fillna("Unknown").str.strip()
df["Age"] = df["Age"].fillna(df["Age"].median())
df["Salary"] = df["Salary"].fillna(df["Salary"].median())
q1 = df["Salary"].quantile(0.25)
q3 = df["Salary"].quantile(0.75)
iqr = q3 - q1
lower = q1 - 1.5 * iqr
upper = q3 + 1.5 * iqr
df["Salary"] = df["Salary"].clip(lower, upper)
print("\nCleaned data:\n", df)

print("\nPART B: Descriptive statistics and visualisation")
print(df.describe(include="all"))
plt.figure()
sns.histplot(df["Age"], kde=True)
plt.title("Age Distribution")
plt.show()
plt.figure()
sns.scatterplot(x="Age", y="Salary", data=df)
plt.title("Age vs Salary")
plt.show()

print("\nPART C: Encoding, scaling and binarization")
data = pd.DataFrame({
    "Feature1": np.random.choice(["A", "B", "C"], 10),
    "Feature2": np.random.randn(10),
    "Feature3": np.random.randint(1, 100, 10),
    "Target": np.random.choice([0, 1], 10)
})
encoder = LabelEncoder()
data["Feature1_encoded"] = encoder.fit_transform(data["Feature1"])
scaler = StandardScaler()
data[["Feature2_scaled", "Feature3_scaled"]] = scaler.fit_transform(
    data[["Feature2", "Feature3"]])
binarizer = Binarizer(threshold=50)
data["Feature3_binarized"] = binarizer.fit_transform(data[["Feature3"]]).astype(int)
print(data)
print("\nPractical 1 completed.")
