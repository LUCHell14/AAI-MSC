# PRACTICAL 4: DISCRIMINATIVE MODELS
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer, load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             confusion_matrix, classification_report, roc_curve, auc)

# A. Logistic Regression: binary classification
data = load_breast_cancer()
X, y = data.data, data.target
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
log_model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000))
log_model.fit(X_train, y_train)
pred = log_model.predict(X_test)
prob = log_model.predict_proba(X_test)[:, 1]
print("LOGISTIC REGRESSION")
print("Accuracy:", accuracy_score(y_test, pred))
print("Precision:", precision_score(y_test, pred))
print("Recall:", recall_score(y_test, pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, pred))
fpr, tpr, _ = roc_curve(y_test, prob)
plt.plot(fpr, tpr, label="AUC = %.3f" % auc(fpr, tpr))
plt.plot([0, 1], [0, 1], "--")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve")
plt.legend()
plt.show()

# B. K-Nearest Neighbors
iris = load_iris()
Xtr, Xte, ytr, yte = train_test_split(
    iris.data, iris.target, test_size=0.2, random_state=42)
knn = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=7))
knn.fit(Xtr, ytr)
knn_pred = knn.predict(Xte)
print("\nKNN accuracy:", accuracy_score(yte, knn_pred))
print("Predictions:", knn_pred)
print("Actual:", yte)

# C. Decision Tree
tree = DecisionTreeClassifier(max_depth=3, random_state=42)
tree.fit(Xtr, ytr)
print("\nDecision Tree accuracy:", tree.score(Xte, yte))
plt.figure(figsize=(12, 7))
plot_tree(tree, feature_names=iris.feature_names,
          class_names=iris.target_names, filled=True)
plt.title("Decision Tree")
plt.show()

# D. Support Vector Machine
svm = make_pipeline(StandardScaler(), SVC(kernel="rbf"))
svm.fit(Xtr, ytr)
print("SVM accuracy:", svm.score(Xte, yte))

# E. Random Forest compared with Decision Tree
forest = RandomForestClassifier(n_estimators=100, max_features="sqrt",
                                random_state=42)
forest.fit(Xtr, ytr)
print("Random Forest accuracy:", forest.score(Xte, yte))

# F. Gradient Boosting
boost = GradientBoostingClassifier(n_estimators=50, learning_rate=0.1,
                                   max_depth=2, random_state=42)
boost.fit(Xtr, ytr)
print("Gradient Boosting accuracy:", boost.score(Xte, yte))
print("\nPractical 4 completed.")
