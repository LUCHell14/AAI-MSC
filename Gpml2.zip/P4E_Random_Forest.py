import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
d=load_iris(); a,b,c,e=train_test_split(d.data,d.target,test_size=.2,random_state=42); t=DecisionTreeClassifier(random_state=1).fit(a,c); print('Decision tree:',accuracy_score(e,t.predict(b)))
ns=[5,10,50,100]; scores=[]
for n in ns:
 m=RandomForestClassifier(n_estimators=n,max_features='sqrt',random_state=1).fit(a,c); z=accuracy_score(e,m.predict(b)); scores.append(z); print(n,'trees accuracy:',z)
plt.plot(ns,scores,marker='o'); plt.xlabel('Number of trees'); plt.ylabel('Accuracy'); plt.show()
