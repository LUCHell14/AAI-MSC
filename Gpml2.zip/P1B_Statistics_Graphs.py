import matplotlib.pyplot as plt, seaborn as sns
from sklearn.datasets import load_iris
iris=load_iris(as_frame=True); df=iris.frame
print(df.describe()); print('Features:',iris.feature_names,'Target: target')
sns.histplot(df['sepal length (cm)'],kde=True); plt.title('Univariate: Sepal Length'); plt.show()
sns.scatterplot(data=df,x='sepal length (cm)',y='petal length (cm)',hue='target'); plt.title('Bivariate'); plt.show()
