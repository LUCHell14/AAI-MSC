# Install first: py -m pip install xgboost
import xgboost as xgb, matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
d=load_breast_cancer(); a,b,c,e=train_test_split(d.data,d.target,test_size=.25,random_state=42); m=xgb.XGBClassifier(n_estimators=50,max_depth=3,learning_rate=.1,eval_metric='logloss').fit(a,c); print('Accuracy:',accuracy_score(e,m.predict(b))); xgb.plot_importance(m,max_num_features=10); plt.show()
