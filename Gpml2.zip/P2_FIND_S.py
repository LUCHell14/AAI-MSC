import csv
rows=[['Sunny','Warm','Normal','Strong','Warm','Same','Yes'],['Sunny','Warm','High','Strong','Warm','Same','Yes'],['Rainy','Cold','High','Strong','Warm','Change','No'],['Sunny','Warm','High','Strong','Cool','Change','Yes']]
with open('enjoysports.csv','w',newline='') as f: csv.writer(f).writerows(rows)
with open('enjoysports.csv') as f: data=list(csv.reader(f))
h=None
for r in data:
 if r[-1].lower()=='yes':
  if h is None: h=r[:-1].copy()
  else: h=[a if a==b else '?' for a,b in zip(h,r[:-1])]
print('Training data:'); [print(r) for r in data]; print('Specific hypothesis:',h)
