import numpy as np, matplotlib.pyplot as plt
np.random.seed(42); data=np.random.normal(5,2,100); prior_mu=0; prior_precision=1; a0=2; b0=2; n=len(data); post_precision=prior_precision+n/4; post_mu=(prior_precision*prior_mu+np.sum(data)/4)/post_precision; post_a=a0+n/2; post_b=b0+np.sum((data-data.mean())**2)/2
mu=np.random.normal(post_mu,1/np.sqrt(post_precision),10000); sigma=np.sqrt(post_b/np.random.gamma(post_a,1,10000))
plt.subplot(1,2,1); plt.hist(mu,bins=30,density=True); plt.title('Posterior mu'); plt.subplot(1,2,2); plt.hist(sigma,bins=30,density=True); plt.title('Posterior sigma'); plt.show(); print('Mean mu:',mu.mean(),'SD:',mu.std()); print('Mean sigma:',sigma.mean(),'SD:',sigma.std())
