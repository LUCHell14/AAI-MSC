from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score,classification_report
d=load_iris(); a,b,c,e=train_test_split(d.data,d.target,test_size=.4,random_state=1); m=GaussianNB().fit(a,c); p=m.predict(b); print('Accuracy (%):',accuracy_score(e,p)*100); print(classification_report(e,p,target_names=d.target_names))
