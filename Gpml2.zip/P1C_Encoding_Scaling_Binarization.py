import pandas as pd, numpy as np
from sklearn.preprocessing import LabelEncoder,StandardScaler,Binarizer
np.random.seed(0); d=pd.DataFrame({'Feature1':np.random.choice(['A','B','C'],10),'Feature2':np.random.randn(10),'Feature3':np.random.randint(1,100,10)})
d['Feature1_encoded']=LabelEncoder().fit_transform(d.Feature1)
d[['Feature2_scaled','Feature3_scaled']]=StandardScaler().fit_transform(d[['Feature2','Feature3']])
d['Feature3_binary']=Binarizer(threshold=50).fit_transform(d[['Feature3']]).astype(int)
print(d)
