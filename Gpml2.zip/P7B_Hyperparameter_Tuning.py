from scipy.stats import randint
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split,GridSearchCV,RandomizedSearchCV
from sklearn.tree import DecisionTreeClassifier
d=load_iris(); a,b,c,e=train_test_split(d.data,d.target,test_size=.2,random_state=42); grid=GridSearchCV(DecisionTreeClassifier(),{'max_depth':[3,5,7,None],'min_samples_split':[2,5,10]},cv=5).fit(a,c); print('Grid best:',grid.best_params_,'accuracy:',grid.score(b,e)); rnd=RandomizedSearchCV(DecisionTreeClassifier(),{'max_depth':randint(1,15),'min_samples_split':randint(2,15)},n_iter=20,cv=5,random_state=1).fit(a,c); print('Random best:',rnd.best_params_,'accuracy:',rnd.score(b,e))
