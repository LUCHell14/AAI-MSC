# Install: py -m pip install hmmlearn
import numpy as np, matplotlib.pyplot as plt
from hmmlearn import hmm
states=['Sunny','Rainy']; obs=['Dry','Wet']; m=hmm.CategoricalHMM(n_components=2,n_features=2); m.startprob_=np.array([.6,.4]); m.transmat_=np.array([[.7,.3],[.3,.7]]); m.emissionprob_=np.array([[.9,.1],[.2,.8]])
x=np.array([0,1,0,1,0,0]).reshape(-1,1); logp,seq=m.decode(x,algorithm='viterbi'); print('Hidden states:',[states[i] for i in seq]); print('Log probability:',logp); plt.plot(seq,'o-'); plt.yticks([0,1],states); plt.show()
