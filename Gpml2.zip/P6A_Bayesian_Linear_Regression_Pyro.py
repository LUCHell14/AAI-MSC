# Install: py -m pip install pyro-ppl
import torch, pyro, pyro.distributions as dist
from pyro.infer import SVI,Trace_ELBO,Predictive
from pyro.optim import Adam
import matplotlib.pyplot as plt
torch.manual_seed(0); pyro.clear_param_store(); X=torch.linspace(0,10,100); Y=1+2*X+torch.randn(100)
def model(X,Y):
 slope=pyro.sample('slope',dist.Normal(0.,10.)); intercept=pyro.sample('intercept',dist.Normal(0.,10.)); sigma=pyro.sample('sigma',dist.HalfNormal(1.));
 with pyro.plate('data',len(X)): pyro.sample('obs',dist.Normal(intercept+slope*X,sigma),obs=Y)
def guide(X,Y):
 sl=pyro.param('sl',torch.tensor(0.)); ss=pyro.param('ss',torch.tensor(1.),constraint=dist.constraints.positive); il=pyro.param('il',torch.tensor(0.)); ins=pyro.param('ins',torch.tensor(1.),constraint=dist.constraints.positive); sig=pyro.param('sig',torch.tensor(1.),constraint=dist.constraints.positive); pyro.sample('slope',dist.Normal(sl,ss)); pyro.sample('intercept',dist.Normal(il,ins)); pyro.sample('sigma',dist.HalfNormal(sig))
svi=SVI(model,guide,Adam({'lr':.01}),loss=Trace_ELBO())
for i in range(500): svi.step(X,Y)
p=Predictive(model,guide=guide,num_samples=300)(X,Y)
for k in ['slope','intercept','sigma']:
 v=p[k].detach().numpy(); print(k,'estimate:',v.mean()); plt.hist(v,bins=25); plt.title(k); plt.show()
