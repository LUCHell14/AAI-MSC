import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
d=load_breast_cancer(); X=d.data[:,:2]; a,b,c,e=train_test_split(X,d.target,test_size=.2,random_state=42); s=StandardScaler(); a=s.fit_transform(a); b=s.transform(b); m=SVC().fit(a,c); print('SVM accuracy:',accuracy_score(e,m.predict(b)))
plt.scatter(b[:,0],b[:,1],c=m.predict(b)); plt.title('SVM prediction'); plt.show()
