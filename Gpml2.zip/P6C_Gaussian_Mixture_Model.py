import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.mixture import GaussianMixture
d=load_iris(); X=d.data[:,:2]; plt.scatter(X[:,0],X[:,1]); plt.title('Original data'); plt.show(); m=GaussianMixture(n_components=3,random_state=1).fit(X); labels=m.predict(X); print('Log likelihood:',m.lower_bound_,'Iterations:',m.n_iter_); plt.scatter(X[:,0],X[:,1],c=labels); plt.title('GMM Clusters'); plt.show()
