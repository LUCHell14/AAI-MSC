MACHINE LEARNING PRACTICALS 1 TO 9 — INDIVIDUAL PYTHON IDLE PROGRAMS

There are 22 separate .py programs, split according to the sub-topics in the journal. Practical 10 is excluded.

Install Python 3.11 (64-bit) from python.org and tick Add Python to PATH. IDLE is included.

In Windows CMD install common libraries:
py -m pip install --upgrade pip
py -m pip install numpy pandas matplotlib seaborn scikit-learn scipy

Optional packages for advanced practicals:
py -m pip install xgboost hmmlearn pyro-ppl pymc arviz torch torchvision

Run: Extract ZIP > open IDLE > File > Open > select a .py file > press F5.

Notes: The journal has some Colab file paths, external CSV dependencies and outdated PyMC3 code. These versions use built-in or generated sample data where possible so they can run locally in IDLE. Practical 6B uses current PyMC instead of old PyMC3. Practical 9 downloads CIFAR-10 and requires internet; it may run slowly on CPU.
