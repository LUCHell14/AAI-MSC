from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge,Lasso,ElasticNet
from sklearn.metrics import mean_squared_error
X,y=make_regression(n_samples=200,n_features=8,noise=10,random_state=1); a,b,c,d=train_test_split(X,y,test_size=.2,random_state=42)
for name,m in [('Ridge',Ridge()),('Lasso',Lasso()),('ElasticNet',ElasticNet())]:
 m.fit(a,c); print(name,'MSE:',mean_squared_error(d,m.predict(b)),'Coefficients:',m.coef_)
