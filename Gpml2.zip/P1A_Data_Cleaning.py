import pandas as pd, numpy as np
df=pd.DataFrame({'Name':['A','B','C','D'],'Country':[' India ','USA',None,'UK'],'Age':[20,np.nan,150,30]})
print('Original\n',df)
df['Country']=df.Country.fillna('Unknown').str.strip(); df['Age']=df.Age.fillna(df.Age.median())
q1,q3=df.Age.quantile([.25,.75]); iqr=q3-q1; df['Age']=df.Age.clip(q1-1.5*iqr,q3+1.5*iqr)
print('Cleaned\n',df)
