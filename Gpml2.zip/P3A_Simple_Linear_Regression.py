import numpy as np, matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error,r2_score
np.random.seed(1); X=np.arange(1,51).reshape(-1,1); y=3*X.ravel()+5+np.random.randn(50)*5
x1,x2,y1,y2=train_test_split(X,y,test_size=.2,random_state=42); m=LinearRegression().fit(x1,y1); pred=m.predict(x2)
print('Coefficient:',m.coef_[0],'Intercept:',m.intercept_,'MSE:',mean_squared_error(y2,pred),'R2:',r2_score(y2,pred))
plt.scatter(X,y); plt.plot(X,m.predict(X),color='red'); plt.show()
