# Journal uses old PyMC3. Install current version: py -m pip install pymc arviz
import numpy as np, matplotlib.pyplot as plt, pymc as pm, arviz as az
np.random.seed(0); X=np.linspace(0,10,100); Y=1+2*X+np.random.normal(0,1,100)
with pm.Model() as model:
 slope=pm.Normal('slope',mu=0,sigma=10); intercept=pm.Normal('intercept',mu=0,sigma=10); sigma=pm.HalfNormal('sigma',sigma=1); pm.Normal('Y_obs',mu=intercept+slope*X,sigma=sigma,observed=Y); trace=pm.sample(1000,tune=500,chains=2,cores=1)
print(az.summary(trace)); az.plot_posterior(trace); plt.show()
