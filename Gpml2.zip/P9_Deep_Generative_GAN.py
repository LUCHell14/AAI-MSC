# CIFAR-10 download requires internet. Install torch and torchvision first.
import torch, torch.nn as nn, torch.optim as optim, matplotlib.pyplot as plt
from torchvision import datasets,transforms,utils
from torch.utils.data import DataLoader,Subset
device='cuda' if torch.cuda.is_available() else 'cpu'; tf=transforms.Compose([transforms.ToTensor(),transforms.Normalize((.5,.5,.5),(.5,.5,.5))]); ds=datasets.CIFAR10('./data',train=True,download=True,transform=tf); dl=DataLoader(Subset(ds,range(1000)),batch_size=32,shuffle=True); zdim=100
class G(nn.Module):
 def __init__(self):
  super().__init__(); self.net=nn.Sequential(nn.Linear(zdim,256),nn.ReLU(),nn.Linear(256,512),nn.ReLU(),nn.Linear(512,3072),nn.Tanh())
 def forward(self,z): return self.net(z).view(-1,3,32,32)
class D(nn.Module):
 def __init__(self):
  super().__init__(); self.net=nn.Sequential(nn.Flatten(),nn.Linear(3072,512),nn.LeakyReLU(.2),nn.Linear(512,1),nn.Sigmoid())
 def forward(self,x): return self.net(x)
g=G().to(device); d=D().to(device); loss=nn.BCELoss(); og=optim.Adam(g.parameters(),lr=.0002); od=optim.Adam(d.parameters(),lr=.0002)
for ep in range(2):
 for real,_ in dl:
  real=real.to(device); n=len(real); ones=torch.ones(n,1,device=device); zeros=torch.zeros(n,1,device=device); noise=torch.randn(n,zdim,device=device); fake=g(noise); od.zero_grad(); ld=(loss(d(real),ones)+loss(d(fake.detach()),zeros))/2; ld.backward(); od.step(); og.zero_grad(); lg=loss(d(g(noise)),ones); lg.backward(); og.step()
 print('Epoch',ep+1,'D loss',ld.item(),'G loss',lg.item())
with torch.no_grad(): grid=utils.make_grid(g(torch.randn(16,zdim,device=device)).cpu(),nrow=4,normalize=True)
plt.imshow(grid.permute(1,2,0)); plt.axis('off'); plt.show()
