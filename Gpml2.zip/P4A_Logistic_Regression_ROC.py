import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import *
d=load_breast_cancer(); a,b,c,e=train_test_split(d.data,d.target,test_size=.2,random_state=42); s=StandardScaler(); a=s.fit_transform(a); b=s.transform(b); m=LogisticRegression(max_iter=3000).fit(a,c); p=m.predict(b)
print('Accuracy:',accuracy_score(e,p)); print(confusion_matrix(e,p)); print(classification_report(e,p))
f,t,_=roc_curve(e,m.predict_proba(b)[:,1]); plt.plot(f,t,label='ROC AUC='+str(auc(f,t))); plt.plot([0,1],[0,1],'--'); plt.legend(); plt.show()
