import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.tree import DecisionTreeClassifier,plot_tree
from sklearn.metrics import accuracy_score
d=load_iris(); a,b,c,e=train_test_split(d.data,d.target,test_size=.2,random_state=42); g=GridSearchCV(DecisionTreeClassifier(random_state=1),{'max_depth':[2,3,4,None]},cv=5).fit(a,c); m=g.best_estimator_; print(g.best_params_,accuracy_score(e,m.predict(b)))
plot_tree(m,feature_names=d.feature_names,class_names=d.target_names,filled=True); plt.show()
