import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error,r2_score
np.random.seed(0); X=np.random.rand(200,3); y=2*X[:,0]+3*X[:,1]+1.5*X[:,2]+np.random.randn(200)*.2
x1,x2,y1,y2=train_test_split(X,y,test_size=.2,random_state=42); m=LinearRegression().fit(x1,y1); p=m.predict(x2)
print('Coefficients:',m.coef_,'MSE:',mean_squared_error(y2,p),'R2:',r2_score(y2,p))
