import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
d=load_iris(); a,b,c,e=train_test_split(d.data,d.target,test_size=.2,random_state=42); m=KNeighborsClassifier(n_neighbors=7).fit(a,c); p=m.predict(b)
print('Predictions:',p,'Accuracy:',accuracy_score(e,p))
for i,(x,y) in enumerate(zip(e,p)): print(i+1,'Actual',d.target_names[x],'Predicted',d.target_names[y],'Correct' if x==y else 'Wrong')
ks=range(1,9); scores=[KNeighborsClassifier(n_neighbors=k).fit(a,c).score(b,e) for k in ks]; plt.plot(list(ks),scores,marker='o'); plt.show()
