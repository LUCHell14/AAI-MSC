from statistics import mean,stdev
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
d=load_breast_cancer(); X=MinMaxScaler().fit_transform(d.data); y=d.target; cv=StratifiedKFold(n_splits=10,shuffle=True,random_state=1); scores=[]
for a,b in cv.split(X,y):
 m=LogisticRegression(max_iter=3000).fit(X[a],y[a]); scores.append(m.score(X[b],y[b]))
print('Fold accuracies:',scores); print('Max:',max(scores)*100,'Min:',min(scores)*100,'Mean:',mean(scores)*100,'Std:',stdev(scores))
